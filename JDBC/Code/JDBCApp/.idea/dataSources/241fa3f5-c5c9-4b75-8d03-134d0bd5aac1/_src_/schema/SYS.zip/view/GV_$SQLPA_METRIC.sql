CREATE VIEW GV_$SQLPA_METRIC AS select "INST_ID","METRIC_NAME" from gv$sqlpa_metric
/
