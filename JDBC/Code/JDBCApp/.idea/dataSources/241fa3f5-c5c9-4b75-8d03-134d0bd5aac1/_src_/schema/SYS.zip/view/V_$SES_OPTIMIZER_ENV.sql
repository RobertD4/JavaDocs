CREATE VIEW V_$SES_OPTIMIZER_ENV AS select "SID","ID","NAME","SQL_FEATURE","ISDEFAULT","VALUE" from v$ses_optimizer_env
/
