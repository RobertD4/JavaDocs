CREATE VIEW V_$DB_PIPES AS select "OWNERID","NAME","TYPE","PIPE_SIZE" from v$db_pipes
/
