CREATE VIEW V_$NLS_PARAMETERS AS select "PARAMETER","VALUE" from v$nls_parameters
/
