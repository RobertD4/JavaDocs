CREATE VIEW V_$SQLPA_METRIC AS select "METRIC_NAME" from v$sqlpa_metric
/
