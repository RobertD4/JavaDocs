CREATE VIEW GV_$NLS_PARAMETERS AS select "INST_ID","PARAMETER","VALUE" from gv$nls_parameters
/
