CREATE VIEW V_$SGA AS select "NAME","VALUE" from v$sga
/
