CREATE VIEW V_$TIMEZONE_FILE AS select "FILENAME","VERSION" from v$timezone_file
/
