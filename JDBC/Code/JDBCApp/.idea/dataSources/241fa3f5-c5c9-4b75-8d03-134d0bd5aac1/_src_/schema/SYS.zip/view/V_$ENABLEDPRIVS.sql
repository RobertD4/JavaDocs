CREATE VIEW V_$ENABLEDPRIVS AS select "PRIV_NUMBER" from v$enabledprivs
/
