CREATE VIEW V_$SEGSTAT_NAME AS select "STATISTIC#","NAME","SAMPLED" from v$segstat_name
/
